sudo apt-get install bison build-essential csh libxaw7-dev libc6-i386
export PATH=$PATH:/usr/class/bin
